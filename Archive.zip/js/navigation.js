
// Custom Toggle
$(document).on("click", ".navigation-toggle", function() {
    $( "body" ).toggleClass( "navigation-open" );
});
